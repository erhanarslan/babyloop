# BabyLoop Stabilization Roadmap

## Purpose

BabyLoop has reached a point where continuing to add features without stabilization will create architectural drift.

This roadmap defines how the current gaps should be fixed step by step.

## Current Situation

BabyLoop currently has a working local full-stack foundation:

- PostgreSQL database
- Drizzle schema and migrations
- Fastify API
- Next.js web app
- auth foundation
- listings
- favorites
- mock AI listing suggestions
- messaging backend foundation

Current stabilization concerns:

- test infrastructure is missing.
- auth is local-MVP level, not production-grade.
- web UI is functional but not polished.
- production readiness is low.
- messaging docs must stay aligned with the profile-pair model.

## Stabilization Rule

Until the current foundation is stable, do not add:

- admin panel
- mobile app
- real AI provider
- image upload pipeline
- payments
- notifications
- full UI redesign
- moderation queue
- realtime messaging
- background workers

## Phase 1: Contract Stabilization

Public API request/response keys use `camelCase`.

Confirmed current direction:

- listing creation uses `categoryId`, `priceAmount`, `listingType`, `imageUrls`.
- favorites use `listingId`.
- messaging uses `listingId` only as listing context input.

Database table and column names remain `snake_case`.

## Phase 2: Messaging Stabilization

Canonical model:

- exactly one conversation channel between two profiles.
- `conversations` uses normalized profile-pair columns: `profile_low_id`, `profile_high_id`.
- listings are attached through `conversation_listing_contexts`.
- `conversation_participants` remains for access checks and future flexibility.
- `messages` stores plain text messages.

The old listing-based conversation model is deprecated.

## Phase 3: Validation and Tests

Recommended next stabilizers:

- add lightweight API tests for auth-protected writes.
- add messaging API tests for participant-only access.
- add migration safety notes before shared DB usage.
- document local dev verification flows.

## Do Not Regress

- Do not revert messaging to listing-based conversations.
- Do not create separate conversations per listing.
- Do not remove `conversation_listing_contexts`.
- Do not reintroduce snake_case API request bodies such as `listing_id`.

## Delayed Work

Do not include in stabilization-only tasks:

- realtime messaging
- message moderation
- reporting/blocking
- notifications
- admin UI
- mobile UI
- real AI providers
- payments
