import { notFound } from "next/navigation";
import { SiteShell } from "../../../components/ui";
import {
  ListingDetailContent,
  ListingDetailUnavailable
} from "../../../features/listings/listing-detail-content";
import {
  fetchApi,
  getApiBaseUrl,
  type ListingDetailPayload
} from "../../../lib/api";

export const dynamic = "force-dynamic";

type ListingDetailPageProps = {
  params: Promise<{
    id: string;
  }>;
};

export default async function ListingDetailPage({ params }: ListingDetailPageProps) {
  const { id } = await params;
  const result = await fetchApi<ListingDetailPayload>(`/api/v1/listings/${id}`);

  if (!result.ok) {
    if (result.error.code === "NOT_FOUND") {
      notFound();
    }

    return (
      <SiteShell>
        <ListingDetailUnavailable error={result.error} />
      </SiteShell>
    );
  }

  const { listing } = result.data;

  return (
    <SiteShell>
      <ListingDetailContent apiBaseUrl={getApiBaseUrl()} listing={listing} />
    </SiteShell>
  );
}
